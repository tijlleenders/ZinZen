## Welcome friend!

If you like Rust and scheduling algorithms you've come to the right place :) We
can talk big-O, add features or optimize hot loops.

> Please contact me tijl.leenders@gmail.com or open an issue.

## Legal stuff

&copy;2020-now ZinZen&reg;

This code is licensed under AGPLv3 but this license does not implicitly grant
permission to use the trade names, trademarks, service marks, or product names
of the licensor, except as required for reasonable and customary use in
describing the origin of the Work and the content of the notice/attribution
file.

ZinZen&reg; supports an open and collaborative process. Registering the
ZinZen&reg; trademark is a tool to protect the ZinZen&reg; identity and the
quality perception of the ZinZen&reg; projects.
